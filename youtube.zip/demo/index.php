<?php

    set_time_limit(0);
	error_reporting(0);
	
	include_once("../vendor/autoload.php");

    use YouTube\Browser;
    $yt = new Browser();
		
	$correctString = $_GET["video_title"];
	$youtubeUrl = "https://www.youtube.com/results?search_query=".urlencode($correctString)."&sp=EgIQAQ%253D%253D&hl=tr&gl=TR";
    $getHTML    = $yt->get($youtubeUrl);

    $data =  str_replace("https://www.youtube.com/", "", $getHTML);
    
	preg_match('@var ytInitialData =(.*?)</script>@si', $data, $bilgi);
	$json = str_replace(array("};", "// scraper_data_end"), array("}", ""), $bilgi[1]);
	
	$youtube_data = json_decode($json); ?>
	
	<b>Total Reselt</b>   : <?php echo $youtube_data->estimatedResults;?><br /><br />
	
<?php
    $say = "0"; 
	foreach($youtube_data->contents->twoColumnSearchResultsRenderer->primaryContents->sectionListRenderer->contents as $datas) {
		foreach($datas->itemSectionRenderer->contents as $datas2) {
			if($datas2->videoRenderer->videoId == "") { } else {
				$say++;
				$description = "";
                foreach($datas2->videoRenderer->descriptionSnippet->runs as $descriptions) {
                    $description .= $descriptions->text;
				}					
			
?>
    	
	<b>Video URL</b>    : <?php echo "https://www.youtube.com/watch?v=".$datas2->videoRenderer->videoId."";?><br />
	<b>Video Image</b>    : <?php echo "http://img.youtube.com/vi/".$datas2->videoRenderer->videoId."/mqdefault.jpg";?><br />
	<b>Video Title</b>    : <?php echo $datas2->videoRenderer->title->runs[0]->text;?><br />
	<b>Video Description</b> : <?php echo $description;?><br />
	<b>Video Count</b>  : <?php echo $datas2->videoRenderer->viewCountText->simpleText;?><br />
	<b>Video Time</b>   : <?php echo $datas2->videoRenderer->lengthText->simpleText;?><br />
	<b>Channel Name</b>    : <?php echo $datas2->videoRenderer->longBylineText->runs[0]->text;?><br />
	<b>Channel ID</b>     : <?php echo $datas2->videoRenderer->longBylineText->runs[0]->navigationEndpoint->browseEndpoint->browseId;?><br />
	<b>Channel Image</b>  : <?php echo $datas2->videoRenderer->channelThumbnailSupportedRenderers->channelThumbnailWithLinkRenderer->thumbnail->thumbnails[0]->url;?><br />
	<b>Video Download</b>    : <a href="<?php echo "youtube_video.php?video_id=".$datas2->videoRenderer->videoId."";?>" target="_blank">Video Download</a><br />
	------------------------------------------------------------<?php echo $say;?>-----------------------------------------------------<br /><br />
	
<?php } } } if($say == "0") {echo "Video Not Found";} ?>