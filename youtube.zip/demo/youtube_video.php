<?php
    set_time_limit(0);
    error_reporting(0);

    include_once("../vendor/autoload.php");
	
	$video_id = $_GET["video_id"];	
	
    use YouTube\Browser;
    $yt = new Browser();
	
    $data_url = $yt->get("../data.php?video_id=".$video_id."");
	$info_url = $yt->get("../info.php?video_id=".$video_id."");
	
	$json_data = json_decode($data_url); 
	$json_info = json_decode($info_url);
	?>

    <b>Video ID:</b> <?php echo $json_info->info->video_id;?><br />
	<b>Video Title:</b> <?php echo $json_info->info->video_title;?><br />
	<b>Video Time:</b> <?php echo $json_info->info->video_time;?><br />
	<b>Video Title:</b> <?php echo $json_info->info->video_title;?><br />
	<b>Video Image:</b> <?php echo $json_info->info->video_image;?><br />
	<b>Video Rating:</b> <?php echo $json_info->info->video_rating;?><br />
	<b>Video Count:</b> <?php echo $json_info->info->video_count;?><br />
	<b>Video Category:</b> <?php echo $json_info->info->video_category;?><br />
	<b>Video Date:</b> <?php echo $json_info->info->video_date;?><br />
	<b>Chennel ID:</b> <?php echo $json_info->info->channel_id;?><br />
	<b>Channel Name:</b> <?php echo $json_info->info->channel_name;?><br />
	<b>Channel URL:</b> <?php echo $json_info->info->channel_url;?><br />
	<b>Video Keywords:</b> <?php echo $json_info->info->video_keywords;?><br />
	<b>Video Description:</b> <?php echo $json_info->info->video_description;?><br /><br />

	---------------------------------Download Links----------------------------------------<br /><br />
	<?php foreach($json_data->info->data as $datas) { ?>
	<b>Format:</b> <?php echo $datas->format;?><br />
    <b>Quality:</b> <?php echo $datas->quality;?><br />
    <b>Size (Byte):</b> <?php echo $datas->size;?><br />
	<b>Boyut (Format):</b> <?php echo $datas->size_format;?><br />
    <b>Download</b> <a href="<?php echo $datas->download_url;?>" target="_blank">Videoyu Download</a><br /><br />
	---------------------------------Download Links----------------------------------------<br /><br />
	<?php } ?>
	

	
		

	














