<?php
		set_time_limit(0);
        error_reporting(0);        
		
		include_once("vendor/autoload.php");
		
        $video_id = $_GET["video_id"];

        use YouTube\YouTubeDownloader;
        $yt = new YouTubeDownloader();

        $youtube_url = "https://www.youtube.com/watch?v=$video_id&hl=tr";
		$links = $yt->getDownloadLinks($youtube_url);
		
		$data = array();
		$data["producer"]    = "AppsTRDesign";
		$data["r10_link"]    = "https://www.r10.net/members/112938-appstrdesign.html";
		$data["github_link"] = "https://github.com/AppsTRDesign";
		$i = "0";
		foreach($links as $data_video){			
				if (itag_true_full($data_video["itag"])){
                        $i++;
                        $size                                   = PHP_file_size($data_video['url']);						
						$data["data"][$i]['format'] 	        = itag_format($data_video['itag']);					
						$data["data"][$i]["quality"] 	        = itag_to_quality_data($data_video['itag']);
						$data["data"][$i]["size"] 		        = $size;
						$data["data"][$i]["size_format"] 		= PHP_file_size_2($size);
						$data["data"][$i]["itag"]               = $data_video['itag'];
						$data["data"][$i]["download_url"]       = $data_video['url'];
						
				}							 
		}
		
        $set['info'] = $data;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
		
	function itag_true_mp3($itag) {
        switch ($itag) {
            case "139":
                return true;
                break;
            case "140":
                return true;
                break;
            case "141":
                return true;
                break;				
            case "171":
                return true;
                break;			
            default:
                return false;
                break;
        }
    }
    
    function itag_true_mp4($itag) {
        switch ($itag) {
            case "18":
                return true;
                break;
            case "22":
                return true;
                break;			
            case "138":
                return true;
                break;				
            case "264":
                return true;
                break;
            case "266":
                return true;
                break;					
            default:
                return false;
                break;
        }
    }
	
    function itag_true_full($itag) {
        switch ($itag) {
            case "18":
                return true;
                break;
            case "22":
                return true;
                break;			
            case "138":
                return true;
                break;				
            case "264":
                return true;
                break;
            case "266":
                return true;
                break;			
            case "139":
                return true;
                break;
            case "140":
                return true;
                break;
            case "141":
                return true;
                break;				
            case "171":
                return true;
                break;				
            default:
                return false;
                break;
        }
    } 	
	
	 function itag_to_quality_data($itag) {
        switch ($itag) {
            case "17":
                return "144P";
                break;
            case "278":
                return "144P";
                break;
            case "36":
                return "240P";
                break;
            case "242":
                return "240P";
                break;
            case "18":
                return "360P";
                break;
            case "243":
                return "360P";
                break;
            case "43":
                return "360P";
                break;
            case "35":
                return "480P";
                break;
            case "44":
                return "480P";
                break;
            case "135":
                return "480P";
                break;
            case "244":
                return "480P";
                break;
            case "22":
                return "720P";
                break;
            case "136":
                return "720P";
                break;
            case "247":
                return "720P";
                break;
            case "137":
                return "1080P";
                break;
            case "248":
                return "1080P";
                break;
            case "299":
                return "1080P (60 FPS)";
                break;
            case "138":
                return "2K";
                break;
            case "264":
                return "2K";
                break;
            case "271":
                return "2K";
                break;
            case "266":
                return "4K";
                break;
            case "313":
                return "4K (60 FPS)";
                break;
            case "139":
                return "48 Kbps";
                break;
            case "140":
                return "128 Kbps";
                break;
            case "141":
                return "128 Kbps";
                break;				
            case "171":
                return "128 Kbps";
                break;
			case "249":
                return "50k";
                break;
			case "250":
                return "70k";
                break;
			case "251":
                return "160k";
                break;				
            default:
                return $itag;
                break;
        }
    } 

	function itag_format($itag) {
        switch ($itag) {
            case "17":
                return '3GP';
                break;
            case "278":
                return 'WEBM';
                break;
            case "36":
                return '3GP';
                break;
            case "242":
                return 'WEBM';
                break;
            case "18":
                return 'MP4';
                break;
            case "243":
                return 'WEBM';
                break;
            case "43":
                return 'WEBM';
                break;
            case "35":
                return 'FLV';
                break;
            case "44":
                return 'WEBM';
                break;
            case "135":
                return 'MP4';
                break;
            case "244":
                return 'WEBM';
                break;
            case "22":
                return 'MP4';
                break;
            case "136":
                return 'MP4';
                break;
            case "247":
                return 'WEBM';
                break;
            case "137":
                return 'MP4';
                break;
            case "248":
                return 'WEBM';
                break;
            case "299":
                return 'MP4';
                break;
            case "138":
                return 'MP4';
                break;
            case "264":
                return 'MP4';
                break;
            case "271":
                return 'WEBM';
                break;
            case "266":
                return 'MP4';
                break;
            case "313":
                return 'WEBM';
                break;
            case "139":
                return 'MP3';
                break;
            case "140":
                return 'MP3';
                break;
            case "141":
                return 'MP3';
                break;				
            case "171":
                return 'WEBM';
                break;
			case "249":
                return 'WEBM';
                break;
			case "250":
                return 'WEBM';
                break;
			case "251":
                return 'WEBM';
                break;				
            default:
                return 'MP4';
                break;
        }
    }
  
	function PHP_file_size_2($bytes){
		switch ($bytes) {
			case $bytes < 1024:
				$size = $bytes . " B";
				break;
			case $bytes < 1048576:
				$size = round($bytes / 1024, 2) . " KB";
				break;
			case $bytes < 1073741824:
				$size = round($bytes / 1048576, 2) . " MB";
				break;
			case $bytes < 1099511627776:
				$size = round($bytes / 1073741824, 2) . " GB";
				break;
		}
		if (!empty($size)) {
			return $size;
		} else {
			return "";
		}
	}
//-- 
	function PHP_file_size($url, $format = false){
		$headers = get_headers($url, 1);
		if (is_array($headers) && count($headers) > 0) {
			$size = $headers['Content-Length'];
			if (is_array($size)) {
				foreach ($size as $value) {
					if ($value != 0) {
						$size = $value;
						break;
					}
				}
			}
			if ($format === true) {
				return PHP_file_size_2($size);
			} else {
				return $size;
			}
		} else {
			return "unknown";
		}
	}