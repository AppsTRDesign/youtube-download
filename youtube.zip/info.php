<?php
		set_time_limit(0);
        error_reporting(0); 

        include_once("vendor/autoload.php");		
		
        $video_id = $_GET["video_id"];
		
        use YouTube\Browser;
        $yt = new Browser();		

        $youtube_url = "https://www.youtube.com/watch?v=$video_id&hl=tr";
        $youtube_data_url =  str_replace('https://www.youtube.com/', '', $yt->get($youtube_url));
	
	    $json_data = getPlayerResponse($youtube_data_url);

		$data = array();
		
		$data["producer"]    = "AppsTRDesign";
		$data["r10_link"]    = "https://www.r10.net/members/112938-appstrdesign.html";
		$data["github_link"] = "https://github.com/AppsTRDesign";
		$data["video_title"] = $json_data["videoDetails"]["title"];
		$data["video_id"]    = $json_data["videoDetails"]["videoId"];
	
        $time = explode(":", gmdate("H:i:s", $json_data["videoDetails"]["lengthSeconds"]));
        if($time[0] == "00") {
            $data["video_time"] = gmdate("i:s", $json_data["videoDetails"]["lengthSeconds"]);
		} else {
            $data["video_time"] = gmdate("H:i:s", $json_data["videoDetails"]["lengthSeconds"]);
        }			
        			
		$data["video_images"] = $json_data["videoDetails"]["thumbnail"]["thumbnails"];
		$data["video_image"] = "http://img.youtube.com/vi/".$json_data["videoDetails"]["videoId"]."/mqdefault.jpg";
		$data["video_rating"] = $json_data["videoDetails"]["averageRating"];
		$data["video_count"] = bd_nice_number($json_data["videoDetails"]["viewCount"]);
		$data["video_category"] = $json_data["microformat"]["playerMicroformatRenderer"]["category"];
		$data["video_date"] = date("d/m/Y", strtotime($json_data["microformat"]["playerMicroformatRenderer"]["publishDate"]));
		$data["channel_id"] = $json_data["videoDetails"]["channelId"];
		$data["channel_name"] = $json_data["videoDetails"]["author"];
		$data["channel_url"] = $json_data["microformat"]["playerMicroformatRenderer"]["ownerProfileUrl"];

		$keywords = "";
		foreach($json_data["videoDetails"]["keywords"] as $keyword) {
			$keywords .= "$keyword,";
		}
        
        $data["video_keywords"] = $keywords;
        $data["video_description"] = nl2br($json_data["microformat"]["playerMicroformatRenderer"]["description"]["simpleText"]);
		
		
        $set['info'] = $data;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
		
	
    function getPlayerResponse($page_html)
    {
        if (preg_match('/player_response":"(.*?)\"}};/', $page_html, $matches)) {
            $match = stripslashes($matches[1]);

            $ret = json_decode($match, true);
            return $ret;
        }

        return null;
    }
	
    function bd_nice_number($n) {
        // first strip any formatting;
        $n = (0+str_replace(",","",$n));
        
        // is this a number?
        if(!is_numeric($n)) return false;
        
        // now filter it;
        if($n>1000000000000) return round(($n/1000000000000),1). " Trilyon";
        else if($n>1000000000) return round(($n/1000000000),1). " Milyar";
        else if($n>1000000) return round(($n/1000000),1). " Milyon";
        else if($n>1000) return round(($n/1000),1). " Bin";
        
        return number_format($n);
    }	